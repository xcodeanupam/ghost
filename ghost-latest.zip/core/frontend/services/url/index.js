const UrlService = require('./UrlService'),
    urlService = new UrlService();

// Singleton
module.exports = urlService;
