module.exports = {
    get input() {
        return require('./input');
    },

    get output() {
        return require('./output');
    }
};
