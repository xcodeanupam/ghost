module.exports = {
    all(model, apiConfig, frame) {
        frame.response = model;
    }
};
