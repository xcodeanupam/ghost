# Content / Logs

This is the default log file location when Ghost runs in Production.
